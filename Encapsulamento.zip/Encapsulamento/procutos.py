# Classe que representa um produto de uma loja
class Produto:

    # Executa quando criamos um produto
    def __init__(self, nome, preco, quantidade):
        self.__nome = nome

        # Verifica se o preço é negativo
        if preco < 0:
            raise ValueError("O preço não pode ser negativo")

        self.__preco = preco

        # Verifica se a quantidade é negativa
        if quantidade < 0:
            raise ValueError("A quantidade não pode ser negativa")

        self.__quantidade = quantidade

    # Permite consultar o nome do produto
    @property
    def nome(self):
        return self.__nome

    # Permite consultar o preço
    @property
    def preco(self):
        return self.__preco

    # Permite alterar o preço com validação
    @preco.setter
    def preco(self, novo_preco):
        if novo_preco < 0:
            raise ValueError("O preço não pode ser negativo")

        self.__preco = novo_preco

    # Permite consultar a quantidade
    @property
    def quantidade(self):
        return self.__quantidade

    # Permite alterar a quantidade com validação
    @quantidade.setter
    def quantidade(self, nova_quantidade):
        if nova_quantidade < 0:
            raise ValueError("A quantidade não pode ser negativa")

        self.__quantidade = nova_quantidade

    # Calcula o valor total do estoque
    def valor_total_estoque(self):
        return self.__preco * self.__quantidade


# Criando um produto: 10 camisetas custando R$ 30 cada
produto1 = Produto("Camiseta", 30.00, 10)

# Consultando os dados do produto
print("Produto:", produto1.nome)
print("Preço: R$", produto1.preco)
print("Quantidade:", produto1.quantidade)
print("Valor total do estoque: R$", produto1.valor_total_estoque())

# Testando uma atualização válida
produto1.preco = 35.00
produto1.quantidade = 12

print("\nApós a atualização:")
print("Novo preço: R$", produto1.preco)
print("Nova quantidade:", produto1.quantidade)
print("Novo valor do estoque: R$", produto1.valor_total_estoque())

# Testando uma atualização inválida
try:
    produto1.preco = -10
except ValueError as erro:
    print("\nErro:", erro)
