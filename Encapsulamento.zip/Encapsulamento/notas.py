class Boletim:
    def __init__(self, aluno):
        self.__aluno = aluno
        self.__notas = []

    # Retorna uma cópia das notas
    @property
    def notas(self):
        return self.__notas.copy()

    # Adiciona uma nota entre 0 e 10
    def adicionar_nota(self, nota):
        if nota < 0 or nota > 10:
            raise ValueError("A nota deve estar entre 0 e 10")
        self.__notas.append(nota)

    # Calcula a média
    def calcular_media(self):
        if len(self.__notas) == 0:
            return 0
        return sum(self.__notas) / len(self.__notas)

    # Verifica se o aluno foi aprovado
    def verificar_situacao(self):
        if self.calcular_media() >= 7:
            return "Aprovado"
        return "Reprovado"


# Criando o boletim
boletim = Boletim("Maria")

boletim.adicionar_nota(8)
boletim.adicionar_nota(7)
boletim.adicionar_nota(9)

print("Notas:", boletim.notas)
print("Média:", boletim.calcular_media())
print("Situação:", boletim.verificar_situacao())