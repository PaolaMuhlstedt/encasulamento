
class Livro:
    def __init__(self, titulo, autor):
        self.__titulo = titulo
        self.__autor = autor
        self.__disponivel = True

    # Consultar os dados
    @property
    def titulo(self):
        return self.__titulo

    @property
    def autor(self):
        return self.__autor

    @property
    def disponivel(self):
        return self.__disponivel

    # Emprestar o livro
    def emprestar(self):
        if not self.__disponivel:
            raise ValueError("Livro já emprestado")
        self.__disponivel = False

    # Devolver o livro
    def devolver(self):
        if self.__disponivel:
            raise ValueError("Livro já disponível")
        self.__disponivel = True


# Testando o código
livro = Livro("Dom Casmurro", "Machado de Assis")

print(livro.titulo, livro.autor, livro.disponivel)

livro.emprestar()
print(livro.disponivel)  # False

livro.devolver()
print(livro.disponivel)  # True

# Testando uma situação inválida
try:
    livro.devolver()
except ValueError as erro:
    print(erro)
