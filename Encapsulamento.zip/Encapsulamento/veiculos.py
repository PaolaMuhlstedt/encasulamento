
class Veiculo:
    def __init__(self, modelo, velocidade_maxima):
        self.__modelo = modelo
        self.__velocidade = 0
        self.__velocidade_maxima = velocidade_maxima

    @property
    def velocidade(self):
        return self.__velocidade

    def acelerar(self, valor):
        if valor <= 0:
            raise ValueError("Valor deve ser positivo")
        if self.__velocidade + valor > self.__velocidade_maxima:
            raise ValueError("Velocidade máxima ultrapassada")
        self.__velocidade += valor

    def frear(self, valor):
        if valor <= 0 or valor > self.__velocidade:
            raise ValueError("Valor de frenagem inválido")
        self.__velocidade -= valor

    def exibir_status(self):
        if self.__velocidade == 0:
            situacao = "Parado"
        elif self.__velocidade == self.__velocidade_maxima:
            situacao = "Na velocidade máxima"
        else:
            situacao = "Em movimento"
        print(self.__modelo, "-", self.__velocidade, "km/h -", situacao)


veiculo = Veiculo("Carro", 120)
veiculo.acelerar(60)
veiculo.exibir_status()
veiculo.acelerar(60)
veiculo.exibir_status()
veiculo.frear(120)
veiculo.exibir_status()