
# Classe que representa um aluno
class Aluno:

    # Executa quando criamos um aluno
    def __init__(self, nome, matricula, nota):
        # Guardando nome e matrícula como atributos privados
        self.__nome = nome
        self.__matricula = matricula

        # Verificando se a nota está entre 0 e 10
        if nota < 0 or nota > 10:
            raise ValueError("A nota deve estar entre 0 e 10")

        # Guardando a nota depois da validação
        self.__nota = nota

    # Permite consultar o nome
    @property
    def nome(self):
        return self.__nome

    # Permite consultar a matrícula
    @property
    def matricula(self):
        return self.__matricula

    # Permite consultar a nota
    @property
    def nota(self):
        return self.__nota

    # Permite alterar a nota com validação
    @nota.setter
    def nota(self, nova_nota):
        if nova_nota < 0 or nova_nota > 10:
            raise ValueError("A nota deve estar entre 0 e 10")

        # Se a nota for válida, ela é salva
        self.__nota = nova_nota


# Criando três alunos
aluno1 = Aluno("Ana", 101, 8.5)
aluno2 = Aluno("Pedro", 102, 7.0)
aluno3 = Aluno("Maria", 103, 9.0)

# Exibindo os dados dos alunos
print("Nome:", aluno1.nome)
print("Matrícula:", aluno1.matricula)
print("Nota:", aluno1.nota)

print("\nNome:", aluno2.nome)
print("Matrícula:", aluno2.matricula)
print("Nota:", aluno2.nota)

print("\nNome:", aluno3.nome)
print("Matrícula:", aluno3.matricula)
print("Nota:", aluno3.nota)


# Alterando a nota da Ana
aluno1.nota = 9.5
print("\nNova nota da Ana:", aluno1.nota)


# Tentando colocar uma nota inválida
try:
    aluno1.nota = 15
except ValueError as erro:
    print("Erro:", erro)
