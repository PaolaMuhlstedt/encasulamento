
class SensorTemperatura:
    def __init__(self, identificacao, temperatura):
        self.__identificacao = identificacao
        self.__temperatura = temperatura  # Valida usando o setter

    # Consultar a temperatura
    @property
    def temperatura(self):
        return self.__temperatura

    # Alterar a temperatura com validação
    @temperatura.setter
    def temperatura(self, valor):
        if valor < -20 or valor > 150:
            raise ValueError("Temperatura deve estar entre -20 e 150 °C")
        self.__temperatura = valor

    # Verificar se a temperatura está em alerta
    def esta_em_alerta(self):
        return self.__temperatura > 80


# Criando um sensor
sensor = SensorTemperatura("S01", 80)
print("Temperatura:", sensor.temperatura, "°C")
print("Está em alerta?", sensor.esta_em_alerta())

# Testando o limite mínimo e máximo
sensor.temperatura = -20
print("Temperatura:", sensor.temperatura, "°C")

sensor.temperatura = 150
print("Temperatura:", sensor.temperatura, "°C")
print("Está em alerta?", sensor.esta_em_alerta())

# Testando um valor inválido
try:
    sensor.temperatura = 160
except ValueError as erro:
    print("Erro:", erro)