
# Classe que representa um funcionário
class Funcionario:

    # Executa quando criamos um funcionário
    def __init__(self, nome, cargo, salario):
        self.__nome = nome
        self.__cargo = cargo

        # O salário inicial não pode ser negativo
        if salario < 0:
            raise ValueError("O salário não pode ser negativo")

        self.__salario = salario

    # Permite consultar o nome
    @property
    def nome(self):
        return self.__nome

    # Permite consultar o cargo
    @property
    def cargo(self):
        return self.__cargo

    # Permite consultar o salário, mas não alterá-lo diretamente
    @property
    def salario(self):
        return self.__salario

    # Aumenta o salário de acordo com um percentual
    def aumentar_salario(self, percentual):
        # O percentual não pode ser negativo
        if percentual < 0:
            raise ValueError("O percentual não pode ser negativo")

        # Calcula o aumento
        aumento = self.__salario * percentual / 100

        # Soma o aumento ao salário atual
        self.__salario += aumento


# Cadastrando dois funcionários
funcionario1 = Funcionario("Ana", "Analista", 2000)
funcionario2 = Funcionario("Pedro", "Gerente", 3500)

# Exibindo os dados iniciais
print("Funcionário:", funcionario1.nome)
print("Cargo:", funcionario1.cargo)
print("Salário: R$", funcionario1.salario)

print("\nFuncionário:", funcionario2.nome)
print("Cargo:", funcionario2.cargo)
print("Salário: R$", funcionario2.salario)

# Aplicando aumentos diferentes
funcionario1.aumentar_salario(10)
funcionario2.aumentar_salario(5)

# Exibindo os novos salários
print("\nNovo salário da Ana: R$", funcionario1.salario)
print("Novo salário do Pedro: R$", funcionario2.salario)

# Testando um percentual inválido
try:
    funcionario1.aumentar_salario(-5)
except ValueError as erro:
    print("Erro:", erro)

# Testando uma alteração direta do salário
try:
    funcionario1.salario = 5000
except AttributeError:
    print("Erro: o salário só pode ser alterado pelo método aumentar_salario()")