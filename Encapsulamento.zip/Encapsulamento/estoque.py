class Estoque:
    def __init__(self, produto, quantidade):
        self.__produto = produto
        self.__quantidade = quantidade
        self.__historico = []

    # Consultar quantidade sem permitir alteração direta
    @property
    def quantidade(self):
        return self.__quantidade

    # Consultar uma cópia do histórico
    @property
    def historico(self):
        return self.__historico.copy()

    # Adicionar produtos ao estoque
    def adicionar_estoque(self, quantidade):
        if quantidade <= 0:
            raise ValueError("A quantidade deve ser positiva")

        self.__quantidade += quantidade
        self.__historico.append(f"Entrada: {quantidade}")

    # Remover produtos do estoque
    def remover_estoque(self, quantidade):
        if quantidade <= 0:
            raise ValueError("A quantidade deve ser positiva")

        if quantidade > self.__quantidade:
            raise ValueError("Estoque insuficiente")

        self.__quantidade -= quantidade
        self.__historico.append(f"Saída: {quantidade}")


# Testando o estoque
estoque = Estoque("Caderno", 10)

estoque.adicionar_estoque(5)
estoque.remover_estoque(3)

print("Quantidade atual:", estoque.quantidade)
print("Histórico:", estoque.historico)
