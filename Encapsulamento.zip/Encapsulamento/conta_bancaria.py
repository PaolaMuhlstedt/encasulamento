
# Criando a classe: ela é o molde da conta bancária
class ContaBancaria:

    # Construtor: inicializa os dados da conta
    def __init__(self, titular, saldo_inicial=0):

        # Verifica se o saldo inicial é negativo
        if saldo_inicial < 0:
            raise ValueError("Saldo inicial inválido")

        # Guarda os dados nos atributos privados
        self.__titular = titular
        self.__saldo = saldo_inicial

    # Getter com @property: permite consultar o saldo
    # Usamos conta.saldo, sem parênteses
    @property
    def saldo(self):
        return self.__saldo

 # Metodo para depositar diheiro
    def depositar(self, valor):

        # O deposito precisa ser maior que zero 
        # raise ValueError Indica que um valor é inválido.
        if valor <= 0:
            raise ValueError("Deposito deve ser positivo")

        # Soma o valor ao saldo atual
        self.__saldo += valor

        # Método para sacar dinheiro 
    def sacar(self, valor):

            # Verifica se o valor é invalido ou maior que o saldo 
            if valor <= 0 or valor > self.__saldo:
                raise ValueError("Saque invalido")

            # Subtrai o valor do saldo atual
            self.__saldo-= valor

# Criando dois objetos fora da classe
conta1 = ContaBancaria("Ana", 100)
conta2 = ContaBancaria("Pedro", 200)

# Realizando operações na conta da Ana
conta1.depositar(50)
conta1.sacar(30)

# Exibindo os saldos
print("Saldo da Ana:", conta1.saldo)
print("Saldo do Pedro:", conta2.saldo)

# Testando um saque inválido
# try = tente executar esse código.
# except = se acontecer o erro esperado, faça isso aqui.
try:
    conta1.sacar(500)
except ValueError as erro:
    print("Erro:", erro)
    